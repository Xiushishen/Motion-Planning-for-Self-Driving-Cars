#include "processor.h"
#include <string>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
    std::ifstream filestream(LinuxParser::kProcDirectory + LinuxParser::kStatFilename);
    if (filestream.is_open())
    {
        while(std::getline(filestream, line))
        {
            std::istringstream linestream(line);
            while ( linestream >> cpu >> user >> nice >> system >> idle >> iowait >>
                    irq >> softirq >> steal >> guest >> guest_nice) {
                if (cpu == "cpu")
                {   
                    int tot_time = std::stoi(user) + std::stoi(nice) +
                                      std::stoi(system) + std::stoi(idle) +
                                      std::stoi(iowait) + std::stoi(irq) +
                                      std::stoi(softirq) + std::stoi(steal);

                    float diff_idle = std::stof(idle.c_str()) - prev_idle_;
                    float diff_total = tot_time - prev_total_;
                    util = std::min((diff_total - diff_idle) / diff_total * 2, 100.f);
                    prev_total_ = tot_time;
                    prev_idle_ = std::stoi(idle);
                    break;
                }
            }
        }
    }
  return util; 
}
